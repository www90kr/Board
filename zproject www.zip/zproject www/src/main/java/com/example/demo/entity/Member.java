package com.example.demo.entity;

import java.time.*;

import com.example.demo.dto.*;
import com.example.demo.dto.MemberDto.*;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Member {
	private String username;		// 사용자 입력
	private String password;		// 서버에서 암호화해서 추가
	private String irum;			// 사용자 입력
	private String email;			// 사용자 입력
	private String profile;			
	private String role;
	private Integer loginFailCnt;
	private Boolean enabled;		// 기본값
	private LocalDate birthday;
	private LocalDate joinday;
	private Level levels;
	private String	checkCode;
	
	
	public void addJoinInfo(String profileName, String encodedPassword) {
		this.profile = profileName;
		this.password = encodedPassword;
		
	}
	public Read toDto() {
		return MemberDto.Read.builder().username(username).irum(irum)
			.email(email).profile(profile)
			.build();
	}
}





