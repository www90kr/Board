package com.example.demo.exception;

public class MemberNotFoundException extends RuntimeException {

}
