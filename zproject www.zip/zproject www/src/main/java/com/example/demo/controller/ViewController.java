package com.example.demo.controller;

import javax.servlet.http.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.service.*;

import springfox.documentation.annotations.*;

@Controller
@ApiIgnore
public class ViewController {
	@Autowired
	private MemberService service;
	
	// 오류가 발생하면 기본적으로 루트로 이동한 다음 오류 메시지를 한번만 출력하고 싶다
	// 오류 메시지는 msg란 이름으로 통일하자
	@GetMapping({"/", "/board/list"})
	public ModelAndView list(HttpSession session) {
		// 세션에 오류메시지가 들었다면 ModelAndView로 이동시킨다
		if(session.getAttribute("msg")!=null) {
			String msg = (String)session.getAttribute("msg");
			session.removeAttribute("msg");
			return new ModelAndView("/board/list").addObject("msg", msg);
		}
		return new ModelAndView("/board/list");
	}
	
	@GetMapping("/board/read")
	public void read() {
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/board/write")
	public void write() {
	}
	
	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/login")
	public void login() {
	}
	
	
	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/join")
	public void join() {
	}
	
	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/check/join")
	public String checkJoin(String checkcode) {
		service.checkJoin(checkcode);
		return "/member/login";
	}
	
	@PreAuthorize("isAnonymous()")
	@GetMapping("/member/find")
	public void find() {
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/member/read")
	public void memberRead() {
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/member/change_password")
	public ModelAndView changePassword(HttpSession session) {
		ModelAndView mav = new ModelAndView("/member/change_password");
		if(session.getAttribute("msg")!=null) {
			mav.addObject("msg", session.getAttribute("msg"));
			session.removeAttribute("msg");
		}
		return mav;
	}
}
